<?php
/* Declaring Indexes */

			if(!isset($varColor))  $varColor = array();
       		if(!isset($varMenu))  $varMenu = array();
        	if(!isset($varStructure))  $varStructure = array();
        	if(!isset($varSlideshow))  $varSlideshow = array();
			if(!isset($data))  $data = array();
			if(!isset($Color))  $Color ='';

			if(!isset($data['Title'])) $data['Title']='';
			if(!isset($data['Color'])) $data['Color']='';
			if(!isset($data['logo'])) $data['logo']='';
			if(!isset($data['style'])) $data['style']='';
			if(!isset($data['page_id'])) $data['page_id']='';
		
			if(!isset($varColor['Title'])) $varColor['Title']='';
			if(!isset($varColor['Color'])) $varColor['Color']='';
			if(!isset($varColor['logo'])) $varColor['logo']='';
			if(!isset($varColor['style'])) $varColor['style']='';
			if(!isset($varColor['page_id'])) $varColor['page_id']='';
			if(!isset($varMenu['side'])) $varMenu['side']='';
			if(!isset($varMenu['top'])) $varMenu['top']='';
			if(!isset($varMenu['menu'])) $varMenu['menu']='';
			if(!isset($varMenu['menuTop'])) $varMenu['menuTop']='';
			if(!isset($varMenu['bottom'])) $varMenu['bottom']='';
			if(!isset($varMenu['menuBottom'])) $varMenu['menuBottom']='';
			if(!isset($varMenu['menuTop'])) $varMenu['menuTop']='';
			if(!isset($varStructure['icon'])) $varStructure['icon']='';
			if(!isset($varStructure['splash'])) $varStructure['splash']='';
			if(!isset($varStructure['description'])) $varStructure['description']='';
			if(!isset($varStructure['keywords'])) $varStructure['keywords']='';
			if(!isset($varStructure['cat'])) $varStructure['cat']='';
			if(!isset($varSlideshow['one'])) $varSlideshow['one']='';
			if(!isset($varSlideshow['two'])) $varSlideshow['two']='';
			if(!isset($varSlideshow['three'])) $varSlideshow['three']='';
			if(!isset($varSlideshow['four'])) $varSlideshow['four']='';
			if(!isset($varSlideshow['five'])) $varSlideshow['five']='';
			if(!isset($varColor['Title'])) $varColor['Title']='';
			if(!isset($varStructure['description'])) $varStructure['description']='';
			if(!isset($varStructure['cat'])) $varStructure['cat']='';
			if(!isset($varStructure['icon'])) $varStructure['icon']='';
			if(!isset($varStructure['splash'])) $varStructure['splash']='';
			if(!isset($varStructure['certificate'])) $varStructure['certificate']='';
