<div style="top:-37px;position: relative;"><img src="<?php echo plugins_url(APPNAME.'/images/newsletter.png')?>" style="width:90%;">

<h3>More Links</h3>
<ul>
	<li><a href="admin.php?page=WordAppCrowd"><font color="red">*** We need your help! *** </font></a></li>

<li><a href="admin.php?page=WordAppMoreDownloads">Get app for free!</a></li>

</ul>
	<h3>Help us grow</h3>
	<p>We promise to invest every cent in to improving the plugin.</p>
										<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="7YT8F3PTRL6LG">
<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_donate_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
</form>

	
	<p><b>Become a reseller</b> <br> Unlimited Apps $99 (White label plugin) <a href="http://community.app-developers.biz/wordapp-reseller/" target="_blank">More information</a></p>
</div>