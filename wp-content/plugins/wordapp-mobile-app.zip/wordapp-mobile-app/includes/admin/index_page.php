<?php
include trailingslashit( plugin_dir_path( __FILE__ ) ) . 'admin_toolbar_misc.php';


	$activate = '';
 	$url = "http://52.27.101.150/mobrock/app/activateJson.php";
	$activate = json_decode(wp_remote_retrieve_body(wp_remote_get($url)),true);	

if(!isset($_GET['quick'])) $_GET['quick'] ='';
if(!isset($_GET['noThanks'])) $_GET['noThanks'] ='';

if($_GET['quick'] == "1" && $_GET['noThanks'] =="1"){
	update_option( 'wordapp_firstCreation', '1' );
}
else if($_GET['quick'] == "1"){
	
	$url64 = base64_encode(get_bloginfo('url'));
	$email64 = base64_encode($_REQUEST[email] );
	$newsletter = base64_encode($_REQUEST['activenewsletter']);
	echo '<img src="http://52.27.101.150/mobrock/app/activatePixel.php?user='.$email64.'&url='.$url64.'&longUrl=&news='.$newsletter.'&format=json">';
			 		
	update_option( 'wordapp_firstVisit', '1' );
	if(!isset($_REQUEST['appName'])) $_REQUEST['appName'] ='';
	if(!isset($_POST['appThemeSelected'])) $_POST['appThemeSelected'] ='';
	
	if($_POST['appThemeSelected'] == "2015") $_POST['appThemeSelected'] = '';

	
	
	list($themeSelected, $themeType)=explode('|', $_POST['appThemeSelected']);
	
if($themeSelected == 'MyiOS'){

	/* install new themes here */
		
		include WORDAPP_DIR.'/themes/wordappjqmobileMyiOS/install.php';
	
	/* end install new themes here */
}else{
	
$myOptionsGet = get_option('WordApp_options');
	if($myOptionsGet == ""){}
	else{
		foreach($myOptionsGet as $option => $value) {
			//echo $option . " => " . $value . "<br />";
			$myOptions[$option] = $value;
		}
	}
	
	$myOptions['Title'] = $_REQUEST['appName'];
	$myOptions['theme'] = $_POST['appThemeSelected'];
	$myOptions['Color'] = '#1e73be';
	$myOptions['style'] = 'tiles';
	 
	
	
update_option('WordApp_options', $myOptions);
	
$myOptions2Get = get_option('WordApp_menu');
	if($myOptions2Get == ""){}
	else{
		foreach($myOptions2Get as $option => $value) {
			//echo $option . " => " . $value . "<br />";
			$myOptions2[$option] = $value;
		}	
	}
	
$myOptions2['side'] = 'on';
		
update_option('WordApp_menu', $myOptions2);
}
	update_option( 'wordapp_firstCreation', '1' );
?>
 <div class="updated" id="" style="padding:10px">
	 <div><b>Install successful</b> 
		 <br>
		 <br>Thank you for using
				<? echo APPNAME_FRIENDLY; ?>,  we hope you enjoy using our plugin.
			  	 If you continue using  <? echo APPNAME_FRIENDLY; ?> you agree to our <a href="http://mobile-rockstar.com/terms-conditions/" > terms of service.</a>
				<br />Thank you for supporting our plugin.
				<div style="float: right;">
				<small><a href="#">Hide</a> </small>
				</div>
			</div>  
		</div> 
<?php
}
?>

	
	<div id="poststuff">

		<div id="post-body" class="metabox-holder columns-2">

			<!-- main content -->
			<div id="post-body-content">

				<div class="meta-box-sortables ui-sortable">

					<div class="postbox">

						<h3><span><?php echo __( 'Welcome to ').APPNAME_FRIENDLY; ?></span></h3>

						<div class="inside">
							

<div style="width:100%;height:100%;height: 400px; float: none; clear: both; margin: 2px auto;">
  <embed src="<?php echo $activate['homeVideo']; ?>?version=3&amp;hl=en_US&amp;rel=0&amp;autohide=1&amp;autoplay=0" wmode="transparent" type="application/x-shockwave-flash" width="100%" height="400px" allowfullscreen="true" title="Adobe Flash Player">
</div>
						<center>	<p><?php echo __('Welcome to ').APPNAME_FRIENDLY.__(', Convert your wordpress site/blog in to a mobile app & mobile site within minutes'); ?></p>
							
						<table style="width:100%;  text-align: center;">
							<tr>
								<td style="width:33%"><img src="<?php echo plugins_url(APPNAME.'/images/target.png'); ?>"><h3><?php echo __('Fast & Reliable');?></h3><?php echo __('Build your mobile app within minutes. It\'s as easy as 1-2-3');?></td>
								<td style="width:33%"><img src="<?php echo plugins_url(APPNAME.'/images/dev.png'); ?>"><h3><?php echo __('No programming skills.');?></h3><?php echo __('No programming skills needed. You don’t need to be a computer wiz-kid to use ').APPNAME;?></td>
								<td style="width:33%"><img src="<?php echo plugins_url(APPNAME.'/images/heart.png'); ?>"><h3><?php echo __('Our Community');?></h3><?php echo __('We started as a bunch of geek and now we have an amazing app-developers.biz community.');?></td>
							</tr>
							</table>
							<h1>Invite your friends and get your android app for FREE!</h1>
					
							<a href="https://twitter.com/share" class="twitter-share-button" data-url="https://wordpress.org/plugins/wordapp-mobile-app/" data-text="Convert your #wordpress site in to a mobile app with #WordApp" data-via="AppDevelopersfr" data-size="large" data-hashtags="Wordpress">Tweet</a>
<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+'://platform.twitter.com/widgets.js';fjs.parentNode.insertBefore(js,fjs);}}(document, 'script', 'twitter-wjs');</script>				
						<div class="fb-share-button" data-href="https://wordpress.org/plugins/wordapp-mobile-app/" data-layout="button_count"></div>	
							<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.5&appId=315852465241124";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>				
<input class="button-primary" type="button" name="send"  id="goToWordApp" style="margin: 12px;width: 300px;height: 54px;font-size: 21px;" value="Get started now!">
		
							</center>
						</div>
						<!-- .inside -->

					</div>
					<!-- .postbox -->

				</div>
				<!-- .meta-box-sortables .ui-sortable -->

			</div>
			<!-- post-body-content -->

			<!-- sidebar -->
			<div id="postbox-container-1" class="postbox-container">

				<div class="meta-box-sortables">

					<div class="postbox">

						<h3><span><?php echo __(
									'Quick Links'
								); ?></span></h3>

						<div class="inside">
							<p>
							<ul>
								<li><a href="http://app-developers.biz/"><?php echo APPNAME_FRIENDLY ?> <?php echo __('website') ?> </a></li>
								<li><a href="https://wordpress.org/support/plugin/wordapp-mobile-app"><?php echo __('Mobile Marketing Community') ?> </a></li>
								<li><a href="http://app-developers.biz/blog/about/"><?php echo APPNAME_FRIENDLY ?> <?php echo __('About App Developers') ?> </a></li>
								<li><a href="https://wordpress.org/plugins/wordapp-mobile-app/changelog/"><?php echo APPNAME_FRIENDLY ?> <?php echo __('Changelog') ?> </a></li>
							
							</ul>
							</p>
				
						</div>
					
						<!-- .inside -->

					</div>
					<!-- .postbox -->
				<div class="postbox" >

						<h3><span><?php echo __(
									'Latest News'
								); ?></span></h3>

						<div class="inside">
							
							<div style="">
							
							<a href="https://twitter.com/share" class="twitter-share-button" data-url="https://wordpress.org/plugins/wordapp-mobile-app/" data-text="Convert your #wordpress site in to a mobile app with #WordApp" data-via="AppDevelopersfr" data-size="large" data-hashtags="Wordpress">Tweet</a>
<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+'://platform.twitter.com/widgets.js';fjs.parentNode.insertBefore(js,fjs);}}(document, 'script', 'twitter-wjs');</script>				
					<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.4&appId=315852465241124";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
							<div class="fb-page" data-href="https://www.facebook.com/AppDevelopersBiz" data-width="275" data-height="600" data-small-header="true" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true" data-show-posts="true"><div class="fb-xfbml-parse-ignore"><blockquote cite="https://www.facebook.com/AppDevelopersBiz"><a href="https://www.facebook.com/AppDevelopersBiz">AppDevelopersBiz</a></blockquote></div></div>
							</div>
					
					
					
					</div>
						<!-- .inside -->

					</div>
					<!-- .postbox -->

				</div>
				<!-- .meta-box-sortables -->

			</div>
			<!-- #postbox-container-1 .postbox-container -->

		</div>
		<!-- #post-body .metabox-holder .columns-2 -->

		<br class="clear">
	</div>
	<!-- #poststuff -->

</div> <!-- .wrap -->
<?php
include trailingslashit( plugin_dir_path( __FILE__ ) ) . 'footer.php';
?>