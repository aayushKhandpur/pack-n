<center>
		<?php echo __('Made with &#10084; by geeks who love wordpress & mobile');?>
</center>
