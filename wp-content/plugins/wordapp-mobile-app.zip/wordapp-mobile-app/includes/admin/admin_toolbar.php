<?php


if ( !current_user_can( 'manage_options' ) )  {
		wp_die( __( 'You do not have sufficient permissions to access this page.' ) );
	}
include WORDAPP_DIR.'/includes/config.php';	
	 $active_tab ='';

	 if( isset( $_GET[ 'tab' ] ) ) {
            $active_tab = $_GET[ 'tab' ];
    							} 
?>
<?php if (!isset($_COOKIE['hidePopWordApp'])):?>
<script>
		jQuery(document).ready(function() {
		var ua = window.navigator.userAgent,
		safari = ua.indexOf ( "Safari" ),
		chrome = ua.indexOf ( "Chrome" ),
		version = ua.substring(0,safari).substring(ua.substring(0,safari).lastIndexOf("/")+1);
//alert(chrome);
	if(chrome > -1) {
		//alert("Should be chrome")
		var urlPopup = '/pushChrome';
	}
	else if(safari > -1) {
		//alert("Should be safari")
		var urlPopup = '';
	}
	else {
		
	}
	
			if(safari > -1 || chrome > -1){
    jQuery.amaran({
        'content'   :{
           title: '<?php _e('WordApp wants to:') ?> ', 
           message:'<?php _e('Send you push notifications'); ?> <br><button id="toastbtnWordApp" class="toastbtnWordApp"><?php _e('Block'); ?></button><button id="toastbtnActiveWordApp" class="toastbtnActiveWordApp"><?php _e('Allow'); ?></button>'
        },
        'position'          :'top left',
        'theme'             :'tumblr',
        'sticky'            :true,
        'closeButton'       :false,
        'closeOnClick'      :false
    });
	}
	
	
jQuery('#toastbtnActiveWordApp').click(function(e) {
			
	var subdomaine = 'appdevelopers'
			 var e = void 0 != window.screenLeft ? window.screenLeft : screen.left,
                i = void 0 != window.screenTop ? window.screenTop : screen.top,
                t = window.innerWidth ? window.innerWidth : document.documentElement.clientWidth ? document.documentElement.clientWidth : screen.width,
                n = window.innerHeight ? window.innerHeight : document.documentElement.clientHeight ? document.documentElement.clientHeight : screen.height,
                a = 600,
                o = 350,
                r = t / 2 - a / 2 + e,
                p = n / 2 - o / 2 + i,
                s = window.open("https://appdevelopers.wppush.co"+urlPopup+"/?siteUUID=" + jQuery.cookie('wppushuuid') + "&domain=" + subdomaine, "_blank", "scrollbars=yes, width=" + a + ", height=" + o + ", top=" + p + ", left=" + r);
            s.focus();
		
		jQuery.amaran.close();
		setCookieSuccessWordApp();
		});

	jQuery('#toastbtnWordApp').click(function(e) {
			
		jQuery.amaran.close();
		jQuery.cookie('hidePopWordApp', '1', { expires: 20 });
	
		});
	});
	
	function setCookieSuccessWordApp(){
		jQuery.cookie('hidePopWordApp', '1', { expires: 60 });
	}
	
</script>
<?php endif; ?>
<div class="wrap">
   
   <div class="wordAppheader"><a href="<?php echo MAINURL; ?>" class="wordApplogo"><img  style="  width: 100%;max-width:250px" src="<?php echo plugin_dir_url(APPNAME.'/images/logo.png', __FILE__); ?>logo.png"></a> <div class="wordAppsubscribe">
	 <h3  style="margin:0px">Subscribe to our newsletter</h3>
	   <form method="post" target="_blank" action="http://app-developers.fr/lists/?p=subscribe&id=3" name="subscribeform">
	   <table border=0>
  <tr>
  <td class="attributeinput"><input type=text name=email value="" placeholder="<?php echo __('Your Email Address'); ?>" size="20" />
 	</td>
	<td class="attributeinput"><input type="hidden" name="htmlemail" value="1" />
            <input type="text" name="attribute1"  class="attributeinput" size="20" placeholder="<?php echo __('Your Name'); ?>" value="" /></td>
	   <td>
		   <input type="hidden" name="list[9]" value="signup" /><input type="hidden" name="listname[9]" value="List WordApp"/><div style="display:none"><input type="text" name="VerificationCodeX" value="" size="20"></div><input type=submit name="subscribe" value="<?php echo __('Subscribe!');?>" 
	  </td>
	   </tr>
		   </table>
    
	   
	   </form>
	   </div>
	   <div style="float:left;text-align:center;margin-left: 140px;">
		     <?php

				/* After accepting the t&c this registers users blog so we can display app and send the android version automatically via email */
		    $url64 = base64_encode(get_bloginfo('url'));

		      if(get_option( 'wordapp_firstVisit' ) == ""){
			  		update_option( 'WordApp_ga', array('mobilesite' => 'on'));
			 		}
		      else{
					}
		   
		   ?>
		   
	  
 <?php  if(get_option( 'wordapp_firstVisit' ) == ""){  ?>
		 <div class="updated" id="" style="">
			<div>Thank you for using
				<? echo APPNAME_FRIENDLY; ?>,  we hope you enjoy using our plugin.
			  	 If you continue using  <? echo APPNAME_FRIENDLY; ?> you agree to our <a href="http://mobile-rockstar.com/terms-conditions/" > terms of service.</a>
				<br />Thank you for supporting our plugin.
				<div style="float: right;">
				<small><a href="#">Hide</a> </small>
				</div>
			</div>  
		</div>  	 
			<?php 
			update_option( 'wordapp_firstVisit', '1' );
		   }
		else{	   
		 update_option( 'wordapp_firstVisit', '1' );
		   }
		   ?>		   
		  
	   </div>
	</div>
         <div id="dashicons-admin-plugins" class="icon32"></div>
   
<h2 class="nav-tab-wrapper">
    
    <a href="?page=WordAppBuilder&tab=" class="nav-tab <?php echo $active_tab == '' ? 'nav-tab-active' : ''; ?>"><?php echo __('Design'); ?></a>
    <a href="?page=WordAppBuilder&tab=step2" class="nav-tab <?php echo $active_tab == 'step2' ? 'nav-tab-active' : ''; ?>"><?php echo __('Menus'); ?></a>
	<a href="?page=WordAppBuilder&tab=slideshow" class="nav-tab <?php echo $active_tab == 'slideshow' ? 'nav-tab-active' : ''; ?>"><?php echo __('Slideshow'); ?></a>
    <a href="?page=WordAppBuilder&tab=step3" class="nav-tab <?php echo $active_tab == 'step3' ? 'nav-tab-active' : ''; ?>"><?php echo __('App Structure'); ?></a>
    <a href="?page=WordAppBuilder&tab=step4" style="background-color: #00a0d2;color: #fff;margin-left: 10%;" class="nav-tab <?php echo $active_tab == 'step4' ? 'nav-tab-active' : ''; ?>"><?php echo __('Publish App'); ?></a>
   
	
</h2>
	<?php
	$varGA = (array)get_option( 'WordApp_ga' );
	if(!isset($varGA['chatHide'])) $varGA['chatHide'] ='';
	if($varGA['chatHide']== ''){
	 ?>
<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5640b758cd3d632538bc617b/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
	<?php
	

	}
	?>
