<?php

if ( !current_user_can( 'manage_options' ) )  {
		wp_die( __( 'You do not have sufficient permissions to access this page.' ) );
	}
include WORDAPP_DIR.'/includes/config.php';

	$active_tab ='';
	 if( isset( $_GET[ 'tab' ] ) ) {
             $active_tab = $_GET[ 'tab' ];
    							} 
?>
<div class="wrap">
   
   <div class="wordAppheader"><a href="<?php echo MAINURL; ?>" class="wordApplogo"><img style="  width: 100%;max-width:250px" src="<?php echo plugin_dir_url(APPNAME.'/images/logo.png', __FILE__); ?>logo.png"></a> <div class="wordAppsubscribe">
	  <h3 style="margin:0px">Subscribe to our newsletter</h3>
	   <form method="post" target="_blank" action="http://app-developers.fr/lists/?p=subscribe&id=3" name="subscribeform">
	   <table border=0>
  <tr>
  <td class="attributeinput"><input type=text name=email value="" placeholder="<?php echo __('Your Email Address'); ?>" size="20" />
 	</td>
	<td class="attributeinput"><input type="hidden" name="htmlemail" value="1" />
            <input type="text" name="attribute1"  class="attributeinput" size="20" placeholder="<?php echo __('Your Name'); ?>" value="" /></td>
	   <td>
		   <input type="hidden" name="list[9]" value="signup" /><input type="hidden" name="listname[9]" value="List WordApp"/><div style="display:none"><input type="text" name="VerificationCodeX" value="" size="20"></div><input type=submit name="subscribe" value="<?php echo __('Subscribe!');?>" 
	  </td>
	   </tr>
</table>
    
	   
	   </form></div>
	    <div style="float:left;text-align:center;margin-left: 140px;">
		    <?php

				/* After accepting the t&c this registers users blog so we can display app and send the android version automatically via email */
		    $url64 = base64_encode(get_bloginfo('url'));

		      if(get_option( 'wordapp_firstVisit' ) == ""){
			  		update_option( 'WordApp_ga', array('mobilesite' => 'on'));
			 	}
		      else{
					}
		   
		   ?>
		 
		
 <?php  if(get_option( 'wordapp_firstVisit' ) == ""){  ?>
	  <div class="updated" id="" style="">
			<div>Thank you for using
				<? echo APPNAME_FRIENDLY; ?>,  we hope you enjoy using our plugin.
			  	 If you continue using  <? echo APPNAME_FRIENDLY; ?> you agree to our <a href="http://mobile-rockstar.com/terms-conditions/" > terms of service.</a>
				<br />Thank you for supporting our plugin.
				<div style="float: right;">
				<small><a href="#">Hide</a> </small>
				</div>
			</div>  
		</div> 
	<?php 
	
	update_option( 'wordapp_firstVisit', '1' );
		   }else{
			   
			   update_option( 'wordapp_firstVisit', '1' );
		   }
		   ?>
		  
	   
	   </div>
	</div>
         <div id="dashicons-admin-plugins" class="icon32"></div>
   <?php
	$varGA = (array)get_option( 'WordApp_ga' );
	if(!isset($varGA['chatHide'])) $varGA['chatHide'] ='';
	if($varGA['chatHide']== ''){
	  ?>
<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5640b758cd3d632538bc617b/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
	<?php
	
	
	}
	?>
