<?php 
$data = array();

$u = 0;


$data[$u]['id'] = $u;
$data[$u]['name'] = "MyiOS|blog";
$data[$u]['title'] = "Blogger";
$data[$u]['category'] = "Night Club";
$data[$u]['url'] = "";
$data[$u]['thumbnail_small'] = "https://secure.buildapps.biz/mobrock/images/screenshot/blog.png";
$u++;


$data[$u]['id'] = $u;
$data[$u]['name'] = "MyiOS|asso";
$data[$u]['title'] = "Friends & Family";
$data[$u]['category'] = "Night Club";
$data[$u]['url'] = "";
$data[$u]['thumbnail_small'] = "https://secure.buildapps.biz/mobrock/images/screenshot/asso.png";
$u++;

$data[$u]['id'] = $u;
$data[$u]['name'] = "MyiOS|nightclub3";
$data[$u]['title'] = "Music / Night Club";
$data[$u]['category'] = "Night Club";
$data[$u]['url'] = "";
$data[$u]['thumbnail_small'] = "https://secure.buildapps.biz/mobrock/images/screenshot/nightclub3.png";
$u++;


$data[$u]['id'] = $u;
$data[$u]['name'] = "MyiOS|squarebtn";
$data[$u]['title'] = "Posh.";
$data[$u]['category'] = "Night Club";
$data[$u]['url'] = "";
$data[$u]['thumbnail_small'] = "https://secure.buildapps.biz/mobrock/images/screenshot/squarebtn.png";
$u++;


$data[$u]['id'] = $u;
$data[$u]['name'] = "MyiOS|rock";
$data[$u]['title'] = "Rock Music";
$data[$u]['category'] = "Night Club";
$data[$u]['url'] = "";
$data[$u]['thumbnail_small'] = "https://secure.buildapps.biz/mobrock/images/screenshot/rock.png";
$u++;


$data[$u]['id'] = $u;
$data[$u]['name'] = "MyiOS|sport";
$data[$u]['title'] = "Sports Football";
$data[$u]['category'] = "Night Club";
$data[$u]['url'] = "";
$data[$u]['thumbnail_small'] = "https://secure.buildapps.biz/mobrock/images/screenshot/sport.png";
$u++;

$data[$u]['id'] = $u;
$data[$u]['name'] = "MyiOS|hair2";
$data[$u]['title'] = "Fasion Hair Salon ";
$data[$u]['category'] = "Night Club";
$data[$u]['url'] = "";
$data[$u]['thumbnail_small'] = "https://secure.buildapps.biz/mobrock/images/screenshot/hair2.png?1A";
$u++;

$data[$u]['id'] = $u;
$data[$u]['name'] = "MyiOS|hair3";
$data[$u]['title'] = "Fasion Hair Salon #2";
$data[$u]['category'] = "Night Club";
$data[$u]['url'] = "";
$data[$u]['thumbnail_small'] = "https://secure.buildapps.biz/mobrock/images/screenshot/hair3.png?1A";
$u++;



$data[$u]['id'] = $u;
$data[$u]['name'] = "MyiOS|desk";
$data[$u]['title'] = "Desk Holiday";
$data[$u]['category'] = "Night Club";
$data[$u]['url'] = "";
$data[$u]['thumbnail_small'] = "https://secure.buildapps.biz/mobrock/images/screenshot/desk.png";
$u++;


$data[$u]['id'] = $u;
$data[$u]['name'] = "MyiOS|church";
$data[$u]['title'] = "Religion";
$data[$u]['category'] = "Night Club";
$data[$u]['url'] = "";
$data[$u]['thumbnail_small'] = "https://secure.buildapps.biz/mobrock/images/screenshot/church.png";
$u++;
 


$data[$u]['id'] = $u;
$data[$u]['name'] = "MyiOS|cars";
$data[$u]['title'] = "Cars automobile";
$data[$u]['category'] = "Night Club";
$data[$u]['url'] = "";
$data[$u]['thumbnail_small'] = "https://secure.buildapps.biz/mobrock/images/screenshot/cars.png";
$u++;
  

$data[$u]['id'] = $u;
$data[$u]['name'] = "MyiOS|photo";
$data[$u]['title'] = "Photograph ";
$data[$u]['category'] = "Photo ";
$data[$u]['url'] = "";
$data[$u]['thumbnail_small'] = "https://secure.buildapps.biz/mobrock/images/screenshot/photo.png";
$u++;

$data[$u]['id'] = $u;
$data[$u]['name'] = "MyiOS|fashion2";
$data[$u]['title'] = "Fasion Blog #2 ";
$data[$u]['category'] = "Night Club";
$data[$u]['url'] = "";
$data[$u]['thumbnail_small'] = "https://secure.buildapps.biz/mobrock/images/screenshot/fashion2.png";
$u++;
 
$data[$u]['id'] = $u;
$data[$u]['name'] = "MyiOS|golf";
$data[$u]['title'] = "Golf Club";
$data[$u]['category'] = "Night Club";
$data[$u]['url'] = "";
$data[$u]['thumbnail_small'] = "https://secure.buildapps.biz/mobrock/images/screenshot/golf.png";
$u++;

$data[$u]['id'] = $u;
$data[$u]['name'] = "MyiOS|suit";
$data[$u]['title'] = "Homme Fashion for men";
$data[$u]['category'] = "Fashion";
$data[$u]['url'] = "";
$data[$u]['thumbnail_small'] = "https://secure.buildapps.biz/mobrock/images/screenshot/suit.png";
$u++;

$data[$u]['id'] = $u;
$data[$u]['name'] = "MyiOS|suit2";
$data[$u]['title'] = "Fashion";
$data[$u]['category'] = "Fashion";
$data[$u]['url'] = "";
$data[$u]['thumbnail_small'] = "https://secure.buildapps.biz/mobrock/images/screenshot/suit2.png";
$u++;

$data[$u]['id'] = $u;
$data[$u]['name'] = "MyiOS|fashion";
$data[$u]['title'] = "iOS Fasion #1";
$data[$u]['category'] = "Fashion";
$data[$u]['url'] = "";
$data[$u]['thumbnail_small'] = "https://secure.buildapps.biz/mobrock/images/screenshot/fashion.png";
$u++;

$data[$u]['id'] = $u;
$data[$u]['name'] = "MyiOS|nightclub2";
$data[$u]['title'] = "NightClub #2";
$data[$u]['category'] = "Night Club";
$data[$u]['url'] = "";
$data[$u]['thumbnail_small'] = "https://secure.buildapps.biz/mobrock/images/screenshot/nightclub2.png";
$u++;

$data[$u]['id'] = $u;
$data[$u]['name'] = "MyiOS|nightclub";
$data[$u]['title'] = "NightClub";
$data[$u]['category'] = "Night Club";
$data[$u]['url'] = "";
$data[$u]['thumbnail_small'] = "https://secure.buildapps.biz/mobrock/images/screenshot/nightclub.png";
$u++;

$data[$u]['id'] = $u;
$data[$u]['name'] = "MyiOS|gym";
$data[$u]['title'] = "iOS Gym";
$data[$u]['url'] = "";
$data[$u]['category'] = "Health";
$data[$u]['thumbnail_small'] = "https://secure.buildapps.biz/mobrock/images/screenshot/gym.png";
$u++;

$data[$u]['id'] = $u;
$data[$u]['name'] = "MyiOS|bigslider";
$data[$u]['title'] = " Beautiful Slider";
$data[$u]['url'] = "";
$data[$u]['category'] = "Health";
$data[$u]['thumbnail_small'] = "https://secure.buildapps.biz/mobrock/images/screenshot/bigslider.png";
$u++;
/*
$data[$u]['id'] = $u;
$data[$u]['name'] = "MyiOS|gym2";
$data[$u]['title'] = "iOS Gym #2";
$data[$u]['url'] = "";
$data[$u]['category'] = "Health";
$data[$u]['thumbnail_small'] = "https://secure.buildapps.biz/mobrock/images/screenshot/gym2.png";
$u++;
*/

$data[$u]['id'] = $u;
$data[$u]['name'] = "MyiOS|biz";
$data[$u]['title'] = "iOS Biz ";
$data[$u]['url'] = "";
$data[$u]['category'] = "Business";
$data[$u]['thumbnail_small'] = "https://secure.buildapps.biz/mobrock/images/screenshot/biz.png";
$u++;

/*
$data[$u]['id'] = $u;
$data[$u]['name'] = "MyiOS|biz2";
$data[$u]['title'] = "iOS Biz #2";
$data[$u]['url'] = "";
$data[$u]['category'] = "Business";
$data[$u]['thumbnail_small'] = "https://secure.buildapps.biz/mobrock/images/screenshot/biz2.png";
$u++;
*/

$data[$u]['id'] = $u;
$data[$u]['name'] = "MyiOS|biz3";
$data[$u]['title'] = "iOS Biz #3";
$data[$u]['url'] = "";
$data[$u]['category'] = "Business";
$data[$u]['thumbnail_small'] = "https://secure.buildapps.biz/mobrock/images/screenshot/biz3.png";
$u++;

/*
$data[$u]['id'] = $u;
$data[$u]['name'] = "MyiOS|biz4";
$data[$u]['title'] = "iOS Biz #4";
$data[$u]['url'] = "";
$data[$u]['category'] = "Business";
$data[$u]['thumbnail_small'] = "https://secure.buildapps.biz/mobrock/images/screenshot/biz4.png";
$u++;
*/

$data[$u]['id'] = $u;
$data[$u]['name'] = "MyiOS|rock";
$data[$u]['title'] = "Rock Star";
$data[$u]['url'] = "";
$data[$u]['category'] = "Music";
$data[$u]['thumbnail_small'] = "https://secure.buildapps.biz/mobrock/images/screenshot/rock.png";
$u++;


$data[110]['id'] = "1";
$data[110]['name'] = "wooWordApp";
$data[110]['title'] = "WooCommerce Theme";
$data[110]['url'] = "";
$data[110]['thumbnail_small'] = "http://52.27.101.150/dev/wordpress/wp-content/plugins/wordapp-mobile-app//themes/icons/woocommerce.png";

/*
$data[112]['id'] = "1";
$data[112]['name'] = "Flat|NightClub";
$data[112]['title'] = "Night Club Beautiful Slider";
$data[112]['url'] = "";
$data[112]['thumbnail_small'] = "http://52.27.101.150/dev/wordpress/wp-content/plugins/wordapp-mobile-app//themes/icons/nightClub.png";



$data[113]['id'] = "1";
$data[113]['name'] = "Flat|Fastfood";
$data[113]['title'] = "Restaurant Beautiful Slider";
$data[113]['url'] = "";
$data[113]['thumbnail_small'] = "http://52.27.101.150/dev/wordpress/wp-content/plugins/wordapp-mobile-app//themes/icons/iconFast.png";


$data[114]['id'] = "1";
$data[114]['name'] = "Flat|Spas";
$data[114]['title'] = "Spa/Health Beautiful Slider";
$data[114]['url'] = "";
$data[114]['thumbnail_small'] = "http://52.27.101.150/dev/wordpress/wp-content/plugins/wordapp-mobile-app//themes/icons/spa.png";


$data[115]['id'] = "1";
$data[115]['name'] = "Flat|Gym";
$data[115]['title'] = "Gym Beautiful Slider";
$data[115]['url'] = "";
$data[115]['thumbnail_small'] = "http://52.27.101.150/dev/wordpress/wp-content/plugins/wordapp-mobile-app//themes/icons/gym.png";

$data[116]['id'] = "1";
$data[116]['name'] = "Flat|Auto";
$data[116]['title'] = "Auto Dealer Beautiful Slider";
$data[116]['url'] = "";
$data[116]['thumbnail_small'] = "http://52.27.101.150/dev/wordpress/wp-content/plugins/wordapp-mobile-app//themes/icons/auto.png";

$data[117]['id'] = "1";
$data[117]['name'] = "Flat|Churches";
$data[117]['title'] = "Church Beautiful Slider";
$data[117]['url'] = "";
$data[117]['thumbnail_small'] = "http://52.27.101.150/dev/wordpress/wp-content/plugins/wordapp-mobile-app//themes/icons/church.png";

$data[118]['id'] = "1";
$data[118]['name'] = "Flat|DJs";
$data[118]['title'] = "Music/DJ Beautiful Slider";
$data[118]['url'] = "";
$data[118]['thumbnail_small'] = "http://52.27.101.150/dev/wordpress/wp-content/plugins/wordapp-mobile-app//themes/icons/dj.png";

$data[119]['id'] = "1";
$data[119]['name'] = "Flat|Chiropractors";
$data[119]['title'] = "Chiropractors Beautiful Slider";
$data[119]['url'] = "";
$data[119]['thumbnail_small'] = "http://52.27.101.150/dev/wordpress/wp-content/plugins/wordapp-mobile-app//themes/icons/chiropractors.png";


$data[1110]['id'] = "1";
$data[1110]['name'] = "Flat|HairSalons";
$data[1110]['title'] = "Hair Salon Beautiful Slider";
$data[1110]['url'] = "";
$data[1110]['thumbnail_small'] = "http://52.27.101.150/dev/wordpress/wp-content/plugins/wordapp-mobile-app//themes/icons/hair.png";

 
$data[1111]['id'] = "1";
$data[1111]['name'] = "Flat|Golf";
$data[1111]['title'] = "Golf Course Beautiful Slider";
$data[1111]['url'] = "";
$data[1111]['thumbnail_small'] = "http://52.27.101.150/dev/wordpress/wp-content/plugins/wordapp-mobile-app//themes/icons/golf.png";
 
$data[1112]['id'] = "1";
$data[1112]['name'] = "Flat|Pub";
$data[1112]['title'] = "Bar/Pub Beautiful Slider";
$data[1112]['url'] = "";
$data[1112]['thumbnail_small'] = "http://52.27.101.150/dev/wordpress/wp-content/plugins/wordapp-mobile-app//themes/icons/pubOrBar.png";

*/

$data[1112]['id'] = "1";
$data[1112]['name'] = "MyTheme";
$data[1112]['title'] = "Default WordPress theme";
$data[1112]['url'] = "";
$data[1112]['thumbnail_small'] = "http://52.27.101.150/dev/wordpress/wp-content/plugins/wordapp-mobile-app//themes/icons/yourTheme.png";



$data[1113]['id'] = "1";
$data[1113]['name'] = "2015";
$data[1113]['title'] = "2015 basic theme";
$data[1113]['url'] = "";
$data[1113]['thumbnail_small'] = "http://52.27.101.150/dev/wordpress/wp-content/plugins/wordapp-mobile-app//themes/icons/2015.png";

/*
$data[1114]['id'] = "1";
$data[1114]['name'] = "Flat|Hairdresser";
$data[1114]['title'] = "Beautiful Slider (Any Biz)";
$data[1114]['url'] = "";
$data[1114]['thumbnail_small'] = "http://52.27.101.150/dev/wordpress/wp-content/plugins/wordapp-mobile-app//themes/icons/slider.png";


*/
//header('Content-Type: application/json');
//$dataThemes =  json_encode($data);