/*
	This file does not excist.
	If you are looking for the unminified version of jquery.mmenu.min.js,
	hava a look at the files jquery.mmenu.oncanvas.js and addons/jquery.mmenu.offcanvas.js
*/
console.group( 'jquery.mmenu.js is an empty file.' );
console.error( 'If you are looking for the unminified version of jquery.mmenu.min.js, hava a look at the files jquery.mmenu.oncanvas.js and addons/jquery.mmenu.offcanvas.js' );
console.groupEnd();