<?php
/*
  Plugin Name: WordApp - Wordpress to Mobile App plugin for WooCommerce & BuddyPress
  Plugin URI: http://App-developers.biz
  Description: Mobile app plugin Convert your wordpress site/blog to mobile app works  WooCommerce  & BuddyPress
  Version:1.15.22
  Author:App-Developers.biz
  Author URI: http://app-developers.biz/
  License: GPLv3
  Copyright: Mobile Rockstar & App-Developers
*/

define('APPNAME', 'wordapp-mobile-app');
define('APPNAME_FRIENDLY', 'WordApp');
define('PLUGIN_URL', 'http://mobile-rockstar.com/app/main/app.php');
define('VIMEO_VIDEO', 'WordApp');
define('MAINURL', 'admin.php?page=WordApp');
define('DEFAULT_WordApp_THEME', 'wordappjqmobile');
define( 'WORDAPP_DIR',dirname( __FILE__ ) );
define( 'WORDAPP_DIR_URL',plugins_url('/',__FILE__) );


require_once WORDAPP_DIR. '/includes/classes/widgets.php';
require_once WORDAPP_DIR. '/includes/classes/create_json.php';
require_once WORDAPP_DIR. '/includes/classes/front_end_widgets.php';
require_once WORDAPP_DIR. '/includes/classes/mobile_pages.php';
require_once WORDAPP_DIR. '/includes/classes/mobile_plugins.php';
require_once WORDAPP_DIR. '/includes/classes/wordapp-homepage.php';
require_once WORDAPP_DIR. '/includes/classes/wordapp-shortcode.php';

$widgets = new WordAppClass_widgets;  // include the custom posts and meta boxes
$createJson = new WordAppClass_json; 
$mobilePlugin = new WordAppClass_mobile_plugin; 
$mobileHomepage = new WordAppHomePage;
$mobilePages = new WordAppClass_mobile_pages;
$mobileShortcode = new WordAppShortcode;

//$wordappWidget = new WordApp_widget; 
//$orgPlugins = new WordAppClass_org_plugins;
class WordAppClass
{


static private $class = null;

  function __construct()
	{
		// actions
	  global $widgets,$createJson,$orgPlugins, $mobilePlugin,$mobileHomepage,$mobilePages,$mobileShortcode;
 		//$this->WordApp_mobile_detect();
		
		$this->init();
		
	  	add_action('init', array($this, 'init'), 1);
		
        /*- actions & filters -*/
		
			add_action('wp_enqueue_scripts', array($this, 'wordapp_enqueue_custom_scripts'));
			add_action( 'admin_enqueue_scripts', array($this, 'WordApp_add_color_picker'));
	  	add_action('wp_head', array($this, 'wordapp_add_my_script'),8);	
	  	add_action( 'wp_footer', array($this, 'WordApp_inc_push_notes'), 99);
	 		add_action( 'wp_head', array($this, 'WordApp_inc_header'), 99);
			add_filter( 'json_prepare_post',  array($this, 'api_to_wordapp'), 10, 3 );
			add_action( 'admin_menu',  array($this, 'register_WordApp_menu'),9 );
			add_action( 'admin_init',  array($this, 'WordAppSettingValues') );
			add_action('init', array($createJson, 'WordApp_produce_my_json'));
	  	add_action('init', array($widgets, 'WordApp_register_widget'));
	  	add_action('init', array($mobilePlugin, 'wordapp_comstom_posts'));
	  	add_action('init', array($mobilePages, 'wordapp_mobile_pages'));
	 	 	add_action('plugins_loaded', array($this, 'WordApp_mobile_detect'));
	 		add_filter( 'init', array( $this, 'WordApp_change_theme_root' ) );
	  	add_action('admin_head-edit.php',array($mobilePlugin, 'wordapp_addCustomImportButton'));
			add_action( 'init', array($mobileShortcode, 'wordapp_get_shortcode'));
	  // Mobile home
		
    // Mobile home
   // add_filter('option_page_on_front', array($this, 'filterOption'));
   // add_filter('option_show_on_front', array($this, 'filter_show_on_front'));
		
			$varColor = (array)get_option( 'WordApp_options' );
   		if ( ($this->wordapp_wp_is_mobile() && $varColor['style'] == 'page') || $_GET['WordApp_launch'] =='1') {
			/* Display and echo mobile specific stuff here */
			//add_filter('option_page_on_front', array($mobileHomepage, 'wordappfilterOption'));
   		//add_filter('option_show_on_front', array($mobileHomepage, 'wordappfilter_show_on_front'));
			add_action( 'template_redirect', array( $mobileHomepage, 'wordapp_template_redirect' ) ); //fix from amclin
		
		 	}
		
			add_action( 'switch_theme', array( $this, 'wordapp_check_theme_dependencies'), 10, 2 );
			add_action( 'after_switch_theme', array( $this, 'wordapp_check_theme_dependencies'), 10, 2 );

			/*-- SHORTCODE --*/
		
			add_shortcode('wordApp_is_mobile', array($mobileShortcode, 'wordapp_shortcode_is_mobile'));
			add_shortcode('wordApp_googlemap', array($mobileShortcode, 'wordapp_googleMapShortcode'));
			add_shortcode( 'wordApp_contact_form', array($mobileShortcode, 'wordapp_contact_shortcode'));
		
			add_shortcode( 'wordApp_tel', array($mobileShortcode, 'wordapp_phone_shortcode'));
			/*-- / SHORTCODE --*/
		
		 /*- WP REST API -*/
		//$this->include_wp_rest_api();
	  

  /*-- Theme switch for mobile sites --*/
		
	}
	function init(){
		
		
	}
	function wordapp_check_theme_dependencies(  $oldtheme_name, $oldtheme ) {
			
    // Admin notice: Theme not activated
   /* add_action( 'admin_notices', 'wordapp_not_activated_admin_notice' );
    function wordapp_not_activated_admin_notice() {
      echo '<div class="update-nag">';
      _e( 'Theme save activated on mobile.', 'wordapp' );
      echo '</div>';
    }
		if(isset($_GET['custom_wordapp'])):
    // Switch back to previous theme
   		switch_theme( $oldtheme->stylesheet );
      return false;
		endif;
		
		*/
		
	// echo "hello"	
	//	print_r($oldtheme);
	//	print_r($oldtheme);
	//	exit;

}
	function WordApp_mobile_detect(){
		global $id, $wpdb,$wp_query;
				if(!isset($_GET['WordApp_mobile_site'])) $_GET['WordApp_mobile_site'] = "";
				if(!isset($_GET['WordApp_demo'])) $_GET['WordApp_demo'] = "";
				if(!isset($_GET['WordApp_mobile_app'])) $_GET['WordApp_mobile_app'] = "";

				if ( ! class_exists( 'Mobile_Detect' ) ){
					require plugin_dir_path( __FILE__ ).'third/Mobile_Detect.php';
					$detect = new Mobile_Detect;
					$is_mobile = $detect->isMobile();	
						$is_tab = $detect->isTablet();	
				}

				$varGA = (array)get_option( 'WordApp_ga' ); 

				if ( isset($_GET['WordApp_mobile_site'])  && $_GET['WordApp_mobile_site'] === 'desktop' ) {
					setcookie( 'WordApp_mobile_site','desktop', time()+3600*6, '/' );
					$_COOKIE['WordApp_mobile_site'] = 'desktop';
				}
		
				if (isset($is_mobile) && $is_mobile == true && !$is_tab && ($_GET['WordApp_mobile_site'] == 'mobile' || $_GET['WordApp_mobile_site'] == '')) {
					setcookie( 'WordApp_mobile_site','mobile', time()+3600*6, '/' );
					$_COOKIE['WordApp_mobile_site'] = 'mobile';
				}

				if (isset($_GET['WordApp_mobile_app'])  && $_GET['WordApp_mobile_app'] === 'app' ) {
					setcookie( 'WordApp_mobile_app',true, time()+3600*6, '/' );
					$_COOKIE['WordApp_mobile_app'] = true;
				}
			 if ( isset($_GET['WordApp_goodbye_mobile'])  &&  $_GET['WordApp_goodbye_mobile'] === '1' ) {
						setcookie( 'WordApp_mobile_app', true, time()-100, '/' );
						unset( $_COOKIE['WordApp_mobile_app'] );
				}

			if((isset($_GET['WordApp_demo']) && $_GET['WordApp_demo'] == '1') || ((isset($_COOKIE['WordApp_mobile_site']) && $_COOKIE['WordApp_mobile_site'] == 'mobile') &&  $varGA['mobilesite'] == "on") || (isset($_COOKIE['WordApp_mobile_app']) && $_COOKIE['WordApp_mobile_app'] == true))  {
			
			$varColor = (array)get_option( 'WordApp_options' );
			
			if(!isset($varColor['theme'])) $varColor['theme']='';
			
			$varHomePages = get_option( 'wordapp_mobile_pages_home' );
			 //$post = get_post($post_id);
				
			
			//echo $varColor['theme'] .' - '.$varHomePages ." == ".$post_ID;
				
			//	echo $slug[0];
				list($themeSelected, $themeType)=explode('|', $varColor['theme']);
				
					if($themeSelected == 'MyiOS'){
						$mobile_home =  $this->get_the_post_id();
					}	
 			
			
				
			if($themeSelected == 'MyiOS' && $varHomePages == $mobile_home ){
				add_action('template_include', array( $this,'WordApp_MyiOSTheme'),100);
			}
			elseif($varColor['theme'] == 'MyTheme'){
					
			add_filter( 'template', array( $this, 'WordApp_mytheme_change_theme' ), 99 );
			add_filter( 'stylesheet', array( $this, 'WordApp_mytheme_change_theme' ), 99 );
			}
			elseif($varColor['theme'] != 'MyiOS'){
			add_filter( 'theme_root',array( $this, 'WordApp_change_theme_root' ), 99 );
			add_filter( 'stylesheet_directory_uri', array( $this, 'WordApp_change_theme_root_css_uri' ), 99 );
			add_filter( 'template_directory_uri', array( $this, 'WordApp_change_theme_root_uri' ), 99 );
			add_filter( 'template', array( $this, 'WordApp_fxn_change_theme' ), 99 );
			add_filter( 'stylesheet', array( $this, 'WordApp_fxn_change_theme' ), 99 );
			}
			else{ 
			//add_filter( 'current_theme', array( $this, 'WordApp_mytheme_change_theme' ),99 );
			add_filter( 'theme_root',array( $this, 'WordApp_change_theme_root' ), 99 );
			add_filter( 'stylesheet_directory_uri', array( $this, 'WordApp_change_theme_root_css_uri' ), 99 );
			add_filter( 'template_directory_uri', array( $this, 'WordApp_change_theme_root_uri' ), 99 );
			add_filter( 'template', array( $this, 'WordApp_fxn_change_theme' ), 99 );
			add_filter( 'stylesheet', array( $this, 'WordApp_fxn_change_theme' ), 99 );
			}
				show_admin_bar(false);
			}	
  }
	function get_the_post_id() {
   global $wpdb;
		if(!isset($_GET['wordapp_mobile_pages'])) $_GET['wordapp_mobile_pages']='';
		if($_GET['wordapp_mobile_pages'] == ''){
  	$link = explode('?', 'http://'.$_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"]);
    $link = str_replace( home_url( '/' ), '', $link[0] );
		
		
		if ( ( $len = strlen( $link ) ) > 0 && $link[$len - 1] == '/' ) {
            $link = substr( $link, 0, -1 );
    }
		$link = explode( '/', $link );
		$slug = end($link);
	}
	else{
		$slug = $_GET['wordapp_mobile_pages'];
	}
   $sql = "
      SELECT
         ID
      FROM
         $wpdb->posts
      WHERE
        post_name = '".$slug."'
   ";
   return $wpdb->get_var($sql);
}
	
	
	function WordApp_get_slugs() {
   		$link = explode('?', 'http://'.$_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"]);
     $link = str_replace( home_url( '/' ), '', $link[0] );
    return  $link;
		/*url_to_postid( $url );
		
		if ( ( $len = strlen( $link ) ) > 0 && $link[$len - 1] == '/' ) {
            $link = substr( $link, 0, -1 );
    }
		
		 	$link = explode( '/', $link );
      
		return end($link);
		
		*/
}
	
	function WordApp_MyiOSTheme() {

			return WORDAPP_DIR.'/themes/wordappjqmobileMyiOS/mainPage.php';
			exit;

	}

	function WordApp_change_theme_root(){
			return plugin_dir_path( __FILE__ ) . 'themes';
	}

	function WordApp_change_theme_root_uri(){ 
		$varColor = (array)get_option( 'WordApp_options' );

		if(!isset($varColor['theme'])) $varColor['theme']='';
		$pieces = explode("|", $varColor['theme']);

	//	$varColor['theme'];
			 // Return the new theme root uri
		if(!isset($varColor['theme'])) $varColor['theme']='';
		$pieces ='';
			if($varColor['theme'] == ''){
				return plugins_url('themes/wordappjqmobile', __FILE__ );
			}
			else{
				$pieces = explode("|", $varColor['theme']);
					return plugins_url('themes/wordappjqmobile'.$pieces[0], __FILE__ );
			}
	}
	function WordApp_change_theme_root_css_uri(){ 
     // Return the new theme root uri
	$varColor = (array)get_option( 'WordApp_options' );
	if(!isset($varColor['theme'])) $varColor['theme']='';
		$pieces ='';
		
		if($varColor['theme'] == ''){
			return plugins_url('themes/wordappjqmobile', __FILE__ );
		}
		else{
			$pieces = explode("|", $varColor['theme']);
			return plugins_url('themes/wordappjqmobile'.$pieces[0], __FILE__ );
			}
	}
	
	
	function WordApp_fxn_change_theme($theme) {
  // Return the new theme root uri
	$varColor = (array)get_option( 'WordApp_options' );
	if(!isset($varColor['theme'])) $varColor['theme']='';
		$pieces ='';
		
		if($varColor['theme'] == ''){
			$theme = DEFAULT_WordApp_THEME;
		}
		else{
			$pieces = explode("|", $varColor['theme']);
			$theme = DEFAULT_WordApp_THEME.$pieces[0];
			}
 
    
  
  	return $theme;
	}
	
	
function WordApp_mytheme_change_theme($theme) {
  // Return the new theme root uri
	$varColor = (array)get_option( 'WordApp_options' );
	if(!isset($varColor['mythemeName'])) $varColor['mythemeName']='';
		$pieces ='';
		
		$theme = $varColor['mythemeName'];
	
    
  
  	return $theme;
	}

	/* ----  Admin Pages ------ */
	function WordAppHomepage(){
		include plugin_dir_path( __FILE__ ).'includes/admin/index_page.php';
	}
	
	function WordAppGetStarted(){
		include plugin_dir_path( __FILE__ ).'includes/admin/start.php';
	}
	
	function WordAppBuilder(){
		include plugin_dir_path( __FILE__ ).'includes/admin/home.php';
	}
	
	function WordAppPN(){
		include plugin_dir_path( __FILE__ ).'includes/admin/push_notes.php';
	}

	function WordAppStats(){
		echo "Stats";	
	}
	
	function WordAppSettings(){
		global $orgPlugins;
		include plugin_dir_path( __FILE__ ).'includes/admin/settings.php';
	}
	
	function WordAppMoreDownloads(){
		include plugin_dir_path( __FILE__ ).'includes/admin/more_downloads.php';
	}
	
	function WordAppMarketing(){
		include plugin_dir_path( __FILE__ ).'includes/admin/marketing_gear.php';
	}

	function WordAppiBeacon(){
		include plugin_dir_path( __FILE__ ).'includes/admin/iBeacon.php';
	}
	
	function WordAppCrowd(){
		include plugin_dir_path( __FILE__ ).'includes/admin/the_crowd.php';
	}

	function WordAppPluginsAndThemes(){

				include plugin_dir_path( __FILE__ ).'includes/admin/plugins.php';
	}
	function WordAppVideos(){

				include plugin_dir_path( __FILE__ ).'includes/admin/videos.php';
	}
	function WordAppCss(){

				include plugin_dir_path( __FILE__ ).'includes/admin/css_editor.php';
	}

	function WordAppGoPro(){
		?>
				<meta http-equiv="refresh"  content="0; url=http://community.app-developers.biz/wordapp-specials/">
				<p>Go premium you are being redirected to more information.
				<a href="http://community.app-developers.biz/wordapp-specials/">If you are not redirected click here</a></p>
		<?php
			exit;			
	}
/* ----  /Admin Pages ------ */



/* -- Registering forms --*/
	function WordAppSettingValues(){

				add_settings_section('WordApp_main', 'Main Settings', 'plugin_section_text', 'WordApp');
				add_settings_field('WordAppColor', 'Theme Toolbar Color', 'WordAppColor_display','WordApp', 'WordApp_main');
				register_setting( 'WordApp_main', 'WordApp_options' );

				add_settings_section('WordApp_main_ga', 'Main Settings', 'plugin_section_text', 'WordApp');
				add_settings_field('WordAppGA', 'Theme Toolbar Color', 'WordAppColor_display','WordApp', 'WordApp_main_ga');
				register_setting( 'WordApp_main_ga', 'WordApp_ga' );

				add_settings_section('WordApp_main_ibeacon', 'Main Settings', 'plugin_section_text', 'WordApp');
				add_settings_field('WordAppibeacon', 'Theme Toolbar Color', 'WordAppColor_display','WordApp', 'WordApp_main_ibeacon');
				register_setting( 'WordApp_main_ibeacon', 'WordApp_ibeacon' );

				add_settings_section('WordApp_main_menu', 'Main Settings', 'plugin_section_text', 'WordApp');
				add_settings_field('WordAppMenu', 'Theme Toolbar Color', 'WordAppColor_display','WordApp', 'WordApp_main_menu');
				register_setting( 'WordApp_main_menu', 'WordApp_menu' );

				add_settings_section('WordApp_main_structure', 'Main Settings', 'plugin_section_text', 'WordApp');
				add_settings_field('WordAppStucutre', 'Theme Toolbar Color', 'WordAppColor_display','WordApp', 'WordApp_main_structure');
				register_setting( 'WordApp_main_structure', 'WordApp_structure' );

				add_settings_section('WordApp_main_slideshow', 'Main Settings', 'plugin_section_text', 'WordApp');
				add_settings_field('WordAppSlideshow', 'Theme Toolbar Color', 'WordAppColor_display','WordApp', 'WordApp_main_slideshow');
				register_setting( 'WordApp_main_slideshow', 'WordApp_slideshow' );

				add_settings_section('WordApp_main_css', 'Main Settings', 'plugin_section_text', 'WordApp');
				add_settings_field('WordAppCss', 'Theme Toolbar Color', 'WordAppColor_display','WordApp', 'WordApp_main_css');
				register_setting( 'WordApp_main_css', 'WordApp_css' );
		
	}
function plugin_section_text() { //TO RENAME
echo '<p>Main description of this section here.</p>';
}

function WordAppColor_display() { //TO RENAME
//$options = get_option('WordAppColor');
//echo "<input id='WordAppColor' name='WordAppColor' size='40' type='text' value='".$options."' />";
} 

function plugin_options_validate($input) { //RENAME
$newinput['text_string'] = trim($input['text_string']);
if(!preg_match('/^[a-z0-9]{32}$/i', $newinput['text_string'])) {
$newinput['text_string'] = '';
}
return $newinput;
}

/* -- /Registering Forms -- */	


/* ----  Admin Menu ------ */


	function register_WordApp_menu(){
		$page_title = "WordApp";
		$menu_title = "WordApp";
		$capability = 'activate_plugins';
		$menu_slug  = "WordApp";
		$function  	= "WordAppHomepage";
		
	//update_option( 'wordapp_firstCreation', '' );
	$GLOBALS['my_page'] = array();
	
	if(get_option( 'wordapp_firstCreation' ) == ""){ 
		$GLOBALS['my_page'][] =  add_menu_page( __('Getting Started'), $menu_title, $capability, $menu_slug, array($this, 'WordAppGetStarted'), plugins_url( APPNAME.'/images/app20x20.png' ), 66 ); 	
		 $GLOBALS['my_page'][] = add_submenu_page( $menu_slug, __('Quick install'), __('Quick Install'), $capability, 'WordAppGetStarted', array($this, 'WordAppGetStarted') );	
	   }else{
		$GLOBALS['my_page'][] = add_menu_page( __('Getting Started'), $menu_title, $capability, $menu_slug, array($this, $function), plugins_url( APPNAME.'/images/app20x20.png' ), 66 ); 
	
	}
	$GLOBALS['my_page'][] =  add_submenu_page( $menu_slug, __('App Builder'), __('App Builder'), $capability, 'WordAppBuilder', array($this, 'WordAppBuilder') );	
	$GLOBALS['my_page'][] = add_submenu_page( $menu_slug, __('Push Notifications'), __('Push Notifications'), $capability, 'WordAppPN', array($this, 'WordAppPN') );
	// add_submenu_page( $menu_slug, __('Stats'), __('Stats'), $capability, 'WordAppStats', array($this, 'WordAppStats') ); // USING GA until find a better solution
	$GLOBALS['my_page_appbuilder'][] = add_submenu_page( $menu_slug, __('Beacons'), __('Beacons'), $capability, 'WordAppiBeacon', array($this, 'WordAppiBeacon') );
		
	$GLOBALS['my_page'][] = add_submenu_page( $menu_slug, __('Marketing Gear'), __('Marketing Gear'), $capability, 'WordAppMarketing', array($this, 'WordAppMarketing') );
	$GLOBALS['my_page'][] = add_submenu_page( 'WordAppSettings', __('The Crowd'), __('The Crowd'), $capability, 'WordAppCrowd', array($this, 'WordAppCrowd') );
	$GLOBALS['my_page'][] = add_submenu_page( $menu_slug, __('Tell a friend'), __('Tell a friend'), $capability, 'WordAppMoreDownloads', array($this, 'WordAppMoreDownloads') );
	$GLOBALS['my_page'][] = add_submenu_page( $menu_slug, __('Video Tutorials'), __('Video Tutorials'), $capability, 'WordAppVideos', array($this, 'WordAppVideos') );
	$GLOBALS['my_page'][] = add_submenu_page( $menu_slug, __('Settings'), __('Settings'), $capability, 'WordAppSettings', array($this, 'WordAppSettings') );
	$GLOBALS['my_page'][] = add_submenu_page( $menu_slug, __('CSS Editor'), __('CSS Editor'), $capability, 'WordAppCss', array($this, 'WordAppCss') );
	$GLOBALS['my_page'][]	= add_submenu_page( $menu_slug, __('Themes'), __('Themes'), $capability, 'WordAppPluginsAndThemes', array($this, 'WordAppPluginsAndThemes') );
	
	if(get_option( 'WordApp_pro' ) == "on"){	
		}else{	
	$GLOBALS['my_page'][] = add_submenu_page( $menu_slug, __('Go Premium'), '<span style="color: #ff5a00;">Go Premium</span>', $capability, 'WordAppGoPro', array($this, 'WordAppGoPro') );
	}
		
	}
/* ----  /Admin Menu ------ */




/* ---Adding WP REST API --- */
	function api_to_wordapp( $_post, $post, $context ) {

	   
	}

	
	 function include_wordApp_rest_api() {
		
		  
		 
	}


/* -- /Adding WP REST API --- */


/* ------------------
* IMPORT CSS & EXTRA LIBS
------------------- */	

 function wordapp_wp_is_mobile() {
    static $is_mobile;

    if ( isset($is_mobile) )
        return $is_mobile;

    if ( empty($_SERVER['HTTP_USER_AGENT']) ) {
        $is_mobile = false;
    } elseif (
        strpos($_SERVER['HTTP_USER_AGENT'], 'Android') !== false
        || strpos($_SERVER['HTTP_USER_AGENT'], 'Silk/') !== false
        || strpos($_SERVER['HTTP_USER_AGENT'], 'Kindle') !== false
        || strpos($_SERVER['HTTP_USER_AGENT'], 'BlackBerry') !== false
        || strpos($_SERVER['HTTP_USER_AGENT'], 'Opera Mini') !== false ) {
            $is_mobile = true;
    } elseif (strpos($_SERVER['HTTP_USER_AGENT'], 'Mobile') !== false && strpos($_SERVER['HTTP_USER_AGENT'], 'iPad') == false) {
            $is_mobile = true;
    } elseif (strpos($_SERVER['HTTP_USER_AGENT'], 'iPad') !== false) {
        $is_mobile = false;
    } else {
        $is_mobile = false;
    }

    return $is_mobile;
}
function wordapp_add_my_script() { 
	
	$varGA = (array)get_option( 'WordApp_ga' );
	if(!isset($varGA['apiLogin'])) $varGA['apiLogin'] ='';
?>
	<script type="text/javascript">
	var appid = '<?php echo $varGA['apiLogin']; ?>';
	</script>

<?php
						 }
/* --- INCLUDING JS for PUSH--- */
	
function WordApp_inc_push_notes( $hook ) {
	//echo $_SERVER['HTTP_USER_AGENT'];
	
$iPod    = stripos($_SERVER['HTTP_USER_AGENT'],"iPod");
$iPhone  = stripos($_SERVER['HTTP_USER_AGENT'],"iPhone");
$iPad    = stripos($_SERVER['HTTP_USER_AGENT'],"iPad");
$Android = stripos($_SERVER['HTTP_USER_AGENT'],"Android");
$webOS   = stripos($_SERVER['HTTP_USER_AGENT'],"webOS");

if ((isset($_GET['WordApp_demo']) && $_GET['WordApp_demo'] == '1') || (isset($_GET['WordApp_mobile_app'])  && $_GET['WordApp_mobile_app'] === 'app' ) || (isset($_COOKIE['WordApp_mobile_app']) && $_COOKIE['WordApp_mobile_app'] == true)){
//do something with this information
	$varColor = (array)get_option( 'WordApp_options' );
	$varGA = (array)get_option( 'WordApp_ga' );
	if(!isset($varGA['apiDomain'])) $varGA['apiDomain'] ='';
			if($varColor['theme'] == "MyTheme" ){
		
			include plugin_dir_path( __FILE__ ).'themes/MyTheme/footer.php'; 
				
				
}	 
}	
   
}

function WordApp_inc_header( $hook ) {
	
		

if ((isset($_GET['WordApp_demo']) && $_GET['WordApp_demo'] == '1') || (isset($_GET['WordApp_mobile_app'])  && $_GET['WordApp_mobile_app'] === 'app' ) || (isset($_COOKIE['WordApp_mobile_app']) && $_COOKIE['WordApp_mobile_app'] == true)){

		$varColor = (array)get_option( 'WordApp_options' );
		$varGA = (array)get_option( 'WordApp_ga' );
		$wamenu = (array)get_option( 'WordApp_menu' );
 		if(!isset($varGA['apiDomain'])) $varGA['apiDomain'] ='';
		if($varColor['theme'] == "MyTheme" ){
	
		include plugin_dir_path( __FILE__ ).'themes/MyTheme/header.php'; 
				
	

}	 
}	
 
}	
		
function wordapp_enqueue_custom_scripts() {
    wp_register_script('googlemaps', ('https://maps.google.com/maps/api/js?sensor=false'), false, null, true);
    wp_enqueue_script('googlemaps');
	
}	
	
/* --- INCLUDING JS for PUSH--- */		
/* -- Color Picker --*/
function WordApp_add_color_picker( $hook ) {
// Make sure to add the wp-color-picker dependecy to js file
/*    
if (preg_match('/^wordapp/', $hook)  || preg_match('/^Wordapp/', $hook)) {
   
} else {
   return false;
}
*/
	if (in_array($hook, $GLOBALS['my_page'])) {
	
	if($_GET['page'] == "WordAppCss"){
		wp_register_script('wordapp_codemirror', plugins_url('codemirror/lib/codemirror.js', __FILE__ ));
    wp_register_style('wordapp_codemirror', plugins_url('codemirror/lib/codemirror.css', __FILE__ ));
 
    wp_register_style('wordapp_cm_blackboard', plugins_url('codemirror/theme/blackboard.css', __FILE__ ));
 
    wp_register_script('wordapp_cm_css', plugins_url('codemirror/css/css.js', __FILE__ ));
	}
 		wp_register_style( 'custom_wordapp_admin_css',  plugins_url( 'css/style.css', __FILE__ ), false, '1.0.0' );
   
		
		wp_register_style('wordapp_css_fonts', plugins_url('css/fontselect.css', __FILE__ ));
    wp_register_script('wordapp_css_font', plugins_url('js/jquery.fontselect.min.js', __FILE__ ));
	
		wp_register_script('wordapp_toastr', plugins_url('js/toastr.js', __FILE__ ));
		wp_register_script('wordapp_toastramaran', plugins_url('js/jquery.amaran.min.js', __FILE__ ));
   	wp_register_script('wordapp_toastramaran', plugins_url('js/jquery.amaran.min.js', __FILE__ ));
   
    wp_register_style('wordapp_toastrcss', plugins_url('css/toastr.css', __FILE__ ));
		wp_register_style('wordapp_toastrcssamaran', plugins_url('css/amaran.min.css', __FILE__ ));
		wp_register_script('wordapp_cookie', plugins_url('js/jquery.cookie.js', __FILE__ ));
   
		wp_register_style( 'custom_wordapp_css_switch',  plugins_url( 'css/switchery.min.css', __FILE__ ), false, '1.0.0' );
   	wp_register_script('custom_wordapp_js_switch', plugins_url('js/switchery.min.js', __FILE__ ));
	
		
		
		wp_enqueue_style( 'wp-color-picker' );
    wp_enqueue_script('jquery');
    wp_enqueue_script('thickbox');
    wp_enqueue_style('thickbox');
    wp_enqueue_script('media-upload');
	 
	  wp_enqueue_style( 'wp-color-picker');
 		wp_enqueue_script( 'wp-color-picker');
		wp_enqueue_script('wordapp_codemirror');
    wp_enqueue_style('wordapp_codemirror');
 
    wp_enqueue_style('wordapp_cm_blackboard');
 
    wp_enqueue_script('wordapp_cm_css');
		wp_enqueue_script( 'cpa_custom_js', plugins_url( 'js/scripts.js?'.date('YmdHsi').'', __FILE__ ), array( 'jquery', 'wp-color-picker','media-upload','thickbox' ), '', true  );
 		wp_enqueue_script( 'wordapp_custom_js',  plugins_url( 'js/jquery.simplyCountable.js', __FILE__ ), array( 'jquery' ), '', true  );
		wp_enqueue_script( 'wordapp_custom_js',  plugins_url( 'js/jquery.simplyCountable.js', __FILE__ ), array( 'jquery' ), '', true  );
	
	 	wp_enqueue_style( 'custom_wordapp_admin_css' );
	
   
		wp_enqueue_script('wordapp_css_font');
    wp_enqueue_style('wordapp_css_fonts');
	 	wp_enqueue_script('wordapp_cookie');
    wp_enqueue_script('wordapp_toastr');
		wp_enqueue_script('wordapp_toastramaran');
		wp_enqueue_style( 'wordapp_toastrcss' );
		wp_enqueue_style( 'wordapp_toastrcssamaran' );
		
	  wp_enqueue_style( 'custom_wordapp_css_switch');
 		wp_enqueue_script( 'custom_wordapp_js_switch');
}
}

function WordApp_options_enqueue_scripts() {
 
}

/* -- /Color Picker --*/
	
	
/* --- Preparing WordApp --- */
	
	
    public function WordApp_activatePlugin()
    {
      // Check for required PHP version
      if (version_compare(PHP_VERSION, '5.0', '<'))
      {
          exit(sprintf('Mobile SMart Pro requires PHP 5.0 or higher. You’re still on %s.',PHP_VERSION));
      }
      
      // check Mobile Smart Pro folder name existence - we need that for MU compatibility  
      if (basename(dirname(__FILE__)) !== APPNAME) {
        exit('The plugin must be installed to wp-content/plugins/wordapp-mobile-app - to help this, please ensure that the zip file you are installing is called wordapp-mobile-app.zip, or rename the folder via FTP');
      }
      

      // idea about moving MU plugins taken from http://wordpress.org/extend/plugins/plugin-organizer/
      if (!file_exists(ABSPATH . "wp-content/mu-plugins/")) {
  			mkdir(ABSPATH . "wp-content/mu-plugins/");
  		}

  		if (file_exists(ABSPATH . "wp-content/mu-plugins/wordapp-mobile-appMU.php")) {
  			unlink(ABSPATH . "wp-content/mu-plugins/wordapp-mobile-appMU.php");
  		}
  		
  		if (file_exists(WP_PLUGIN_DIR . "/" . plugin_basename(dirname(__FILE__)) . "/includes/classes/wordapp-mobile-appMU.php")) {
  			copy(WP_PLUGIN_DIR . "/" . plugin_basename(dirname(__FILE__)) . "/includes/classes/wordapp-mobile-appMU.php", ABSPATH . "wp-content/mu-plugins/wordapp-mobile-appMU.php");
  		}
    }
    
    /**
     * Plugin deactivation
     */
    public function WordApp_deactivatePlugin() {
      if (file_exists(ABSPATH . "wp-content/mu-plugins/wordapp-mobile-appMU.php")) {
  			@unlink(ABSPATH . "wp-content/mu-plugins/wordapp-mobile-appMU.php");
  		}
    }
	
	
	
}//END CLASS


function wordapp_register_widgets() {
	register_widget( 'WordApp_widget' );
}

add_action( 'widgets_init', 'wordapp_register_widgets' );


function WordAppClass()
{
	global $WordAppClass;

	if( !isset($WordAppClass) )
	{
		$WordAppClass = new WordAppClass();
	}

	return $WordAppClass;
}

/* ---- / Widgets ------ */
/*--- Install Hook ----*/
//register_activation_hook( __FILE__, array('WordAppClass', 'WordApp_activate') );
	  
// initialize

if (class_exists("WordAppClass"))
{
  $wordapp_mobile = new WordAppClass();
  // Activation
  register_activation_hook(__FILE__, array(&$wordapp_mobile, 'WordApp_activatePlugin'));
  register_deactivation_hook(__FILE__, array(&$wordapp_mobile, 'WordApp_deactivatePlugin'));
}

