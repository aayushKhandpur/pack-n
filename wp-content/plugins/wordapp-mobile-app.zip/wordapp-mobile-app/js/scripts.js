
jQuery(document).ready(function($){
	
	
	var elems = Array.prototype.slice.call(document.querySelectorAll('.js-switch'));

elems.forEach(function(html) {
  var switchery = new Switchery(html, { size: 'small' });
});
    // Add Color Picker 
    $( '.cpa-color-picker' ).wpColorPicker();  
    var i = "";
   $('.advancedColors').click(function(e) {
      e.preventDefault();
		$( ".advancedColorsDiv" ).slideToggle();
   });
	
	 $('.fontpicker').fontselect();
	
   // Click steps
		//Cancel
    $('.install-startup').click(function(e) {
      e.preventDefault();
		//alert("hello");
		var i = 1;
		var name = $(this).data('name');
		
		$('.install-startup').removeClass('active-install');
	 	$(this).addClass('active-install');
		
		$('.install-startup').html('Install Now');
		$('.active-install').html('Installed');
		$('#appThemeSelected').val(name);
		
	
	});
	//Cancel
    $('.cancelReturn').click(function(e) {
      e.preventDefault();
		//alert("hello");
		var i = 1;
	$('#appName').fadeIn();
	$('#thirdStep').hide();
	$('#appTheme').hide();
			
	$('.progress .circle').removeClass().addClass('circle');
	$('.progress .bar').removeClass().addClass('bar');
	$('.progress .circle:nth-of-type(' + i + ')').addClass('active');
	$('.progress .circle:nth-of-type(3) .label').html('3');
	$('.progress .circle:nth-of-type(2) .label').html('2');
	$('.progress .circle:nth-of-type(1) .label').html('1');
		
        return false;
    });
	//Step #1
    $('#submitStepOne').click(function(e) {
      e.preventDefault();
		//alert("hello");
		var i = 2;
		var oldval = $('#appNameInput').val();
		
		
		var neval = oldval.toLowerCase()
        .replace(/[^\w ]+/g,'')
		.replace(/[^a-zA-Z]+/g, '')
        .replace(/ +/g,'');
		
		var name = neval;
		if(!name){
			alert('You must enter a valid app name');
			return false;
		}
	$('#appName').hide();
	$('#thirdStep').hide();
	$('#appTheme').fadeIn();
			
	$('.progress .circle').removeClass().addClass('circle');
	$('.progress .bar').removeClass().addClass('bar');
	$('.progress .circle:nth-of-type(' + i + ')').addClass('active');
	$('.progress .circle:nth-of-type(' + (i-1) + ')').removeClass('active').addClass('done');
	$('.progress .circle:nth-of-type(' + (i-1) + ') .label').html('&#10003;');
 	$('.progress .bar:nth-of-type(' + (i-1) + ')').addClass('active');
  	$('.progress .bar:nth-of-type(' + (i-2) + ')').removeClass('active').addClass('done');
		$('#appNameInput').val(name);
		 $('#nameChoosen').html(name);
		
		
        return false;
    });
	
	//Step #1
    $('#submitStepTwo').click(function(e) {
     e.preventDefault();
		//alert("hello");
		var i = 3;
		var name = $('#appThemeSelected').val();
		if(!name){
			confirm('You must choose a theme!');
			return false;
		}
	$('#appName').hide();
	$('#appTheme').hide();
	$('#thirdStep').fadeIn();
			
	$('.progress .circle').removeClass().addClass('circle');
	$('.progress .bar').removeClass().addClass('bar');
	$('.progress .circle:nth-of-type(' + i + ')').addClass('active');
	$('.progress .circle:nth-of-type(' + (i-1) + ')').removeClass('active').addClass('done');
	$('.progress .circle:nth-of-type(' + (i-2) + ')').removeClass('active').addClass('done');
	$('.progress .circle:nth-of-type(' + (i-1) + ') .label').html('&#10003;');
 	$('.progress .bar:nth-of-type(' + (i-1) + ')').addClass('active');
  	$('.progress .bar:nth-of-type(' + (i-2) + ')').removeClass('active').addClass('done');
		$('#themeChoosen').html(name);
		
        return false;
    });
	
	
   // Add UPLOAD LOGO
    $('#upload_logo_button').click(function() {
        tb_show('Upload a logo', 'media-upload.php?TB_iframe=true', false);
        i = "logo";
        return false;
    });
	
	$('#upload_background_button').click(function() {
        tb_show('Upload a background', 'media-upload.php?TB_iframe=true', false);
        i = "background";
        return false;
    });
     // Add UPLOAD LOGO
    $('#upload_logo_button_icon').click(function() {
        tb_show('Upload a icon', 'media-upload.php?TB_iframe=true', false);
        i = "icon";
        return false;
    });
      // Add UPLOAD Splash
    $('#upload_logo_button_splash').click(function() {
        tb_show('Upload a splash', 'media-upload.php?TB_iframe=true', false);
        i = "splash";
        return false;
    });
	
	//Upload slideshow
	$('#upload_slideshow_one').click(function() {
        tb_show('Upload a slide', 'media-upload.php?TB_iframe=true', false);
        i = "slideone";
        return false;
    });
	
	$('#upload_slideshow_two').click(function() {
        tb_show('Upload a slide', 'media-upload.php?TB_iframe=true', false);
        i = "slidetwo";
        return false;
    });
	
	$('#upload_slideshow_three').click(function() {
        tb_show('Upload a slide', 'media-upload.php?TB_iframe=true', false);
        i = "slidethree";
        return false;
    });
	
	$('#upload_slideshow_four').click(function() {
        tb_show('Upload a slide', 'media-upload.php?TB_iframe=true', false);
        i = "slidefour";
        return false;
    });
	
	$('#upload_slideshow_five').click(function() {
        tb_show('Upload a slide', 'media-upload.php?TB_iframe=true', false);
        i = "slidefive";
        return false;
    });
	
	 $('#fullpreviewApp').click(function() {
		var theurlStuff = $('#fullpreviewApp').data("id");
		
		
		  tb_show('Preview you app',  theurlStuff + '&TB_iframe=true', false);
        	i = "fullPreview";
        
        return false;
    });
	 $('#fullpreviewApp2').click(function() {
		var theurlStuff = $('#fullpreviewApp2').data("id");
		
		
		  tb_show('Preview you app',  theurlStuff + '&TB_iframe=true', false);
        	i = "fullPreview";
        
        return false;
    });
	  $('#fullpreviews').contents().find('a').click(function(event) {
        alert("This is only a demo click ont the full preview button above to view your app in full.");
        event.preventDefault();
    }); 
	
	 $('#previewApp').click(function() {
        tb_show('Preview you app in mobile web browser', '#TB_inline?inlineId=myPreview&height=400&width=400&modal=false');
        i = "preview";
		 // #TB_window width: 440px;
		 $("#TB_window").width('440px');
        return false;
    });

	 $('#previewApp2').click(function() {
        tb_show('Preview you app in mobile web browser', '#TB_inline?inlineId=myPreview&height=400&width=400&modal=false');
        i = "preview";
		 // #TB_window width: 440px;
		 $("#TB_window").width('440px');
        return false;
    });


  	//Hide show page list	
  	$('#listStyle').click(function(){
    		$("#pageInfo").hide();
			$("#pageInfoList").show();
			$("#pageInfoTiles").hide();
		
	});
	$('#pageStyle').click(function(){
    		$("#pageInfo").show();
			$("#pageInfoList").hide();
			$("#pageInfoTiles").hide();
	});
	$('#tilesStyle').click(function(){
    		$("#pageInfo").hide();
			$("#pageInfoList").hide();
			$("#pageInfoTiles").show();
	});
	
	//Bottom Bar Hide Show
	$('#bottomBarOff').click(function(){
    		$("#bottomInfo").hide();
	});
	$('#bottomBarOn').click(function(){
    		$("#bottomInfo").show();
	});
	//top Bar Hide Show
	$('#topBarOff').click(function(){
    		$("#topInfo").hide();
	});
	$('#topBarOn').click(function(){
    		$("#topInfo").show();
	});
	//side Bar Hide Show
	$('#sideBarOff').click(function(){
    		$("#sideInfo").hide();
	});
	$('#sideBarOn').click(function(){
    		$("#sideInfo").show();
	});
	$('#pushNoteSend').click(function(){
    		window.location.href = 'http://members.app-developers.biz/wordapp-specials/?user=' + $('#user').val()+ '&email=' +  $('#email').val()+ '&url=' +  $('#url').val()+ '&download=' +  $('#download').val();
	});
	$('#goToWordApp').click(function(){
    		window.location.href = 'admin.php?page=WordAppBuilder';
	});
	$('#goCommunity').click(function(){
    		window.location.href = 'http://community.app-developers.biz/?user=' + $('#user').val();
	});
	
 $('#jqIcons').click(function() {
        tb_show('Icon list', 'https://api.jquerymobile.com/resources/icons-list.html?TB_iframe=true', false);
        i = "jquery icons";
        return false;
    });
	
		//After uploading call this script
  	
	window.original_send_to_editor = window.send_to_editor;
		//After uploading call this script
  		window.send_to_editor = function(html) {
 			var image_url = $('img',html).attr('src');
 			// alert(image_url);
 			
 			if(i == "logo"){ 
 			$('#logo_url').attr('src',image_url);
 			 $('#WordAppColor_logo').val(image_url);
 			 }
				else if( i == "background"){ 
 			$('#background_url').attr('src',image_url);
 			 $('#WordAppColor_background').val(image_url);
 			 }
 			 else if( i == "splash"){ 
 			$('#splash_url').attr('src',image_url);
 			 $('#WordAppColor_splash').val(image_url);
 			 }
 			 else if(i == "icon"){ 
 			$('#icon_url').attr('src',image_url);
 			 $('#WordAppColor_icon').val(image_url);
 			 }
			else if(i == "slideone"){ 
 			$('#icon_urlss_one').attr('src',image_url);
 			 $('#WordApp_slideshow_1').val(image_url);
 			 }
			else if(i == "slidetwo"){ 
 			$('#icon_urlss_two').attr('src',image_url);
 			 $('#WordApp_slideshow_2').val(image_url);
 			 }
			else if(i == "slidethree"){ 
 			$('#icon_urlss_three').attr('src',image_url);
 			 $('#WordApp_slideshow_3').val(image_url);
 			 }
			else if(i == "slidefour"){ 
 			$('#icon_urlss_four').attr('src',image_url);
 			 $('#WordApp_slideshow_4').val(image_url);
 			 }
			else if(i == "slidefive"){ 
 			$('#icon_urlss_five').attr('src',image_url);
 			 $('#WordApp_slideshow_5').val(image_url);
 			 }else{
				window.original_send_to_editor(html);
			 }
 			 
 			 
			tb_remove();
		} ;
	
		$('#txtCount').simplyCountable({
		    counter: '#counter',
        countType: 'characters ',
        maxCount: 105,
        countDirection: 'down'
		  });
	
	 $("#sendPush").click( function(e)
           {
		  var apikey = $('#apiKey').val();
		  var apiLogin = $('#apiLogin').val();
         
		 var fullUrl = 'http://52.27.101.150/mobrock/app/pnSend.php?apiKey='+apikey+'&apiLogin='+apiLogin+'&message='+$('#txtCount').val()+'';
		//alert(fullUrl);
		 if(apikey === '' || apiLogin === '' || $('#txtCount').val() ===''){
			 
			  alert("There seems to be a problem. Please check you API codes and try again.");
							 
		 }else{
		 $.ajax({
 		 			 type: 'GET',
				 	 url: fullUrl,
				 	 dataType: 'jsonp',
				 	 success: function(jsonData) {
					 //alert(jsonData['pnTrue']);
						 if(jsonData.pnSent == 'true'){
							 alert("Your message was sent! Depending on the number of downloads, sending may take a few hours.");
							 
						 }else{
							 alert("Your message was sent! Depending on the number of downloads, sending may take a few hours.");
							 
						 }
  					},
  			error: function() {
   					  alert("Your message was sent! Depending on the number of downloads, sending may take a few hours.");
							  }
				});
           }
	 });//End Send Push
	
	
	$("#submitPub").click( function(e)
           {
		
		 var user = $('#user').val();
		 var blogname = $('#blogname').val();
		 var name = $('#name').val();
		 var url = $('#url').val();
		 var email = $('#email').val();
		
		 var fullUrl = 'http://52.27.101.150/mobrock/app/pubSend.php?blogname='+blogname+'&user='+user+'&url='+url+'&name='+name+'&email=' + email + '&message='+$('#txtCount').val()+'&callback=?';
		
		 $.ajax({
 		 			 type: 'GET',
				 	 url: fullUrl,
				 	 dataType: 'json',
				 	 success: function(jsonData) {
					 //alert(jsonData['pnTrue']);
						 if(jsonData.pubSent === 'true'){
							 alert("Your message was sent to our developers! To get your app for free don\'t forget to invites some frients!\n\n\n  Or help us with our crowdfunding efforts :)");
							 window.location.href = 'admin.php?page=WordAppMoreDownloads';
						 }else{
							 
							  alert("There seems to be a problem. Please check you API codes and try again.");
							 
						 }
  					},
  			error: function() {
  			 alert("Your message was sent to our developers! To get your app for free don\'t forget to invites some frients!\n\n\n  Or help us with our crowdfunding efforts :)");
							 window.location.href = 'admin.php?page=WordAppMoreDownloads';
 					 }
				});
           
	 });//End Send Publication
	
	$("#submitPubPro").click( function(e)
           {
		
		 var user = $('#user').val();
		 var blogname = $('#blogname').val();
		 var name = $('#name').val();
		 var url = $('#url').val();
		 var email = $('#email').val();
		
		 var fullUrl = 'http://52.27.101.150/mobrock/app/pubSend.php?blogname='+blogname+'&user='+user+'&url='+url+'&name='+name+'&email=' + email + '&message='+$('#txtCount').val()+'&callback=?';
		
		 $.ajax({
 		 			 type: 'GET',
				 	 url: fullUrl,
				 	 dataType: 'json',
				 	 success: function(jsonData) {
					 //alert(jsonData['pnTrue']);
						 if(jsonData.pubSent === 'true'){
							 alert("Your message was sent to our developers! To get your app for free don\'t forget to invites some frients!\n\n\n  Or help us with our crowdfunding efforts :)");
							 window.location.href = 'admin.php?page=WordAppMoreDownloads';
						 }else{
							 
							  alert("There seems to be a problem. Please check you API codes and try again.");
							 
						 }
  					},
  			error: function() {
  			 alert("Your message was sent to our developers! To get your app for free don\'t forget to invites some frients!\n\n\n  Or help us with our crowdfunding efforts :)");
							 window.location.href = 'admin.php?page=WordAppMoreDownloads';
 					 }
				});
           
	 });//End Send Publication
	
	 $("#inviteFriends").click( function(e)
           {
		  var user = $('#user').val();
		  var blogname = $('#blogname').val();
		 	var name = $('#name').val();
		 var url = $('#url').val();
         
		 var fullUrl = 'http://mobile-rockstar.com/app/invite.php';
		//alert(fullUrl);
		 if(name === '' || user === '' || $('#emails').val() ===''){
			 
			  alert("There seems to be a problem. Both your name & your friends emails addresses are required.");
							 
		 }else{
		 $.ajax({
 		 			 type: 'POST',
				 	 url: fullUrl,
					 data: { 
       				 	'emails': $('#emails').val(), 
        				'name': name,
						 'user': user,
						 'blogname': blogname,
						 'url': url
							},
				 	 dataType: 'jsonp',
				 	 success: function(jsonData) {
					 //alert(jsonData['pnTrue']);
						 if(jsonData.inviteSent === 'true'){
							 alert("THANK YOU!! Your message was sent! Your account will be updated in a few hours.");
							 window.location.href = 'https://members.app-developers.biz/wordapp-specials/';
						 }else{
							 
							  alert("There seems to be a problem. Please check &  try again.");
							 
						 }
  					},
  			error: function() {
   					  	alert("THANK YOU!! Your message was sent! Your account will be updated in a few hours.");
						window.location.href = 'https://members.app-developers.biz/wordapp-specials/'; 
						 }
				});
           }
	 }); // END INVITE
	
var formHasChanged = false;
var submitted = false;

$(document).on('change', '#mainForm', function (e) {
    formHasChanged = true;
});

    window.onbeforeunload = function (e) {
        if (formHasChanged && !submitted) {
            var message = "You have not saved your changes.", e = e || window.event;
            if (e) {
                e.returnValue = message;
            }
            return message;
        }
    };
	
 $("form").submit(function() {
     submitted = true;
     });
});



